package com.suaxe.core.dao;

import com.suaxe.core.data.dao.GenericDAO;
import com.suaxe.core.persistence.data.YeuCauKhachHangEntity;

public interface YeuCauKhachHangDAO extends GenericDAO<Integer, YeuCauKhachHangEntity> {
}

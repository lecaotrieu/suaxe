package com.suaxe.core.dao;

import com.suaxe.core.data.dao.GenericDAO;
import com.suaxe.core.persistence.data.KhachHangEntity;

public interface KhachHangDAO extends GenericDAO<Integer, KhachHangEntity> {
}

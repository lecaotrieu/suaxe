package com.suaxe.core.common.constant;

public class CoreConstant {
    public static final String SORT_ASC = "1";
    public static final String SORT_DESC = "2";
    public static final String FOLDER_UPLOAD = "upload";

}

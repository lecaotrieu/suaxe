package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.YeuCauKhachHangDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.YeuCauKhachHangEntity;

public class YeuCauKhachHangDAOImpl extends AbstractDAO<Integer, YeuCauKhachHangEntity> implements YeuCauKhachHangDAO {
}

package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.KhachHangDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.KhachHangEntity;

public class KhachHangDAOImpl extends AbstractDAO<Integer, KhachHangEntity> implements KhachHangDAO {
}

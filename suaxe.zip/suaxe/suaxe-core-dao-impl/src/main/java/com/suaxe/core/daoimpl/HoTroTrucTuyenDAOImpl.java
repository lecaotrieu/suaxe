package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.HoTroTrucTuyenDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.HoTroTrucTuyenEntity;

public class HoTroTrucTuyenDAOImpl extends AbstractDAO<Integer, HoTroTrucTuyenEntity> implements HoTroTrucTuyenDAO {
}

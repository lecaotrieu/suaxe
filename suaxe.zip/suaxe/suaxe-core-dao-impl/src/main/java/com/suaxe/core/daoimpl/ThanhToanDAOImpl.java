package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.ThanhToanDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.ThanhToanEntity;

public class ThanhToanDAOImpl extends AbstractDAO<Integer, ThanhToanEntity> implements ThanhToanDAO {
}

package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.DichVuDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.DichVuEntity;

public class DichVuDAOImpl extends AbstractDAO<Integer, DichVuEntity> implements DichVuDAO {
}

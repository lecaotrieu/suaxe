package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.ChiTietDichVuDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.ChiTietDichVuEntity;

public class ChiTietDichVuDAOImpl extends AbstractDAO<Integer, ChiTietDichVuEntity> implements ChiTietDichVuDAO {

}

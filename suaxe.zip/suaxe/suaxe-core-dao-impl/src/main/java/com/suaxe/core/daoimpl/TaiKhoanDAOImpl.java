package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.TaiKhoanDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.TaiKhoanEntity;

public class TaiKhoanDAOImpl extends AbstractDAO<Integer, TaiKhoanEntity> implements TaiKhoanDAO {
}

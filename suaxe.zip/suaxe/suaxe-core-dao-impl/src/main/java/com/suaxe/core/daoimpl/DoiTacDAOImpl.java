package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.DoiTacDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.DoiTacEntity;

public class DoiTacDAOImpl extends AbstractDAO<Integer, DoiTacEntity> implements DoiTacDAO {
}

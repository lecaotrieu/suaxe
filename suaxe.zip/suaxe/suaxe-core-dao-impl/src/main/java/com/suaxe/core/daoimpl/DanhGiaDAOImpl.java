package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.DanhGiaDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.DanhGiaEntity;

public class DanhGiaDAOImpl extends AbstractDAO<Integer, DanhGiaEntity> implements DanhGiaDAO {
}

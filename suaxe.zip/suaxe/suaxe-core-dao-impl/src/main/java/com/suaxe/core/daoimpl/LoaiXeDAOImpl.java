package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.LoaiXeDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.LoaiXeEntity;

public class LoaiXeDAOImpl extends AbstractDAO<Integer, LoaiXeEntity> implements LoaiXeDAO {
}

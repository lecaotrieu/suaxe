package com.suaxe.core.daoimpl;

import com.suaxe.core.dao.QuyenDAO;
import com.suaxe.core.data.daoimpl.AbstractDAO;
import com.suaxe.core.persistence.data.QuyenEntity;

public class QuyenDAOImpl extends AbstractDAO<Integer, QuyenEntity> implements QuyenDAO {
}

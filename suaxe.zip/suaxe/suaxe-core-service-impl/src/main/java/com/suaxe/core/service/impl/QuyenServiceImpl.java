package com.suaxe.core.service.impl;

import com.suaxe.core.service.QuyenService;

public class QuyenServiceImpl implements QuyenService {
}

package com.suaxe.core.service.impl;

import com.suaxe.core.service.LoaiXeService;

public class LoaiXeServiceImpl implements LoaiXeService {
}

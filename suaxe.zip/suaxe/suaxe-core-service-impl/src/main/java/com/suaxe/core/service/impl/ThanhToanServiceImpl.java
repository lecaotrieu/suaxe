package com.suaxe.core.service.impl;

import com.suaxe.core.service.ThanhToanService;

public class ThanhToanServiceImpl implements ThanhToanService {
}

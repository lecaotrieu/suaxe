package com.suaxe.core.service.impl;

import com.suaxe.core.service.DoiTacService;

public class DoiTacServiceImpl implements DoiTacService {
}

package com.suaxe.core.service.impl;

import com.suaxe.core.service.ChiTietDichVuService;

public class ChiTietDichVuServiceImpl implements ChiTietDichVuService {
}

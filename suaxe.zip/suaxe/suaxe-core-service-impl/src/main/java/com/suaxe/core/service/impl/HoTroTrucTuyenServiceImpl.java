package com.suaxe.core.service.impl;

import com.suaxe.core.service.HoTroTrucTuyenService;

public class HoTroTrucTuyenServiceImpl implements HoTroTrucTuyenService {
}

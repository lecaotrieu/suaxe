package com.suaxe.core.service.impl;

public class YeuCauKhachHangServiceImpl {
}

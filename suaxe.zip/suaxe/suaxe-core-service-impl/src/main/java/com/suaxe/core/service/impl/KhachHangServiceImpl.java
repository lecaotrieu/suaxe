package com.suaxe.core.service.impl;

import com.suaxe.core.service.KhachHangService;

public class KhachHangServiceImpl implements KhachHangService {
}

package com.suaxe.core.service;

public interface KhachHangService {
}

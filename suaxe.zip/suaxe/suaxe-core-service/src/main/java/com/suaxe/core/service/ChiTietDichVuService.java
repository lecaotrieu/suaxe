package com.suaxe.core.service;

public interface ChiTietDichVuService {
}

package com.suaxe.core.service;

public interface LoaiXeService {
}

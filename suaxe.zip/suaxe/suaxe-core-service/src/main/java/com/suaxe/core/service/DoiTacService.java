package com.suaxe.core.service;

public interface DoiTacService {
}

package com.suaxe.core.service;

public interface HoTroTrucTuyenService {
}

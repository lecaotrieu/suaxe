package com.suaxe.core.utils;

public class ThanhToanBeanUtil {
}

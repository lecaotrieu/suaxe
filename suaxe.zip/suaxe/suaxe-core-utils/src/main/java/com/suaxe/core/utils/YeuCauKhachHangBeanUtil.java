package com.suaxe.core.utils;

public class YeuCauKhachHangBeanUtil {
}
